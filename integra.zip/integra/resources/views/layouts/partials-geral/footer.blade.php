  
   <script src="{{ asset('js/app.js') }}"></script>

</body>

</html>