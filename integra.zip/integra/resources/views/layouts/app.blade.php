@include('layouts.partials-geral.head')
@include('layouts.partials-geral.header')
    <div class="container">
      @yield('content')
    </div>
@include('layouts.partials-geral.footer')
