@include('layouts.partials-user.head')
@include('layouts.partials-user.header')
    <div class="container">
      @yield('content')
    </div>
@include('layouts.partials-user.footer')
