@include('emp.layouts.partials.head')
@include('emp.layouts.partials.header')
    <div class="container">
      @yield('content')
    </div>
@include('emp.layouts.partials.footer')
