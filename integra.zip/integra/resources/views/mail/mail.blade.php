Olá {{ $name }}, seu cadastro em nossa plataforma {{ $var }}.
<br/>
At. Equipe Integra.
