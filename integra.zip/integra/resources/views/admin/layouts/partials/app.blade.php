@include('admin.layouts.partials.head')
@include('admin.layouts.partials.header')
	<div class="container">
	  @yield('content')
	</div>
@include('admin.layouts.partials.footer')
