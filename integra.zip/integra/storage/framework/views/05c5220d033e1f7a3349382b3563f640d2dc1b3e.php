

<?php $__env->startSection('content'); ?>
<style type="text/css">
    @media  only screen and (min-width: 700px) {
        #idiomas {
            margin-left: 82%;
        }
    }

    @media  only screen and (max-width: 600px) {
        #idiomas {
            margin-left: 80%;
        }
    }

    .required {
        color: red;
    }
</style>


    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Conhecimento</div>
                <div class="panel-body">
                    <table class="table table-hover">
                        <thead>
                            <button href="#myModalsave" class="btn btn-success pull-right" data-toggle="modal"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>Nova</button></span></button></a>
                            <tr>
                              <th>Nome</th>
                              <th>Remover</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $userconhecimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userconhecimento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $conhecimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conhecimento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($userconhecimento->id_conhecimento == $conhecimento->id): ?>

                                    <tr>
                                        <td><?php echo e($conhecimento->name); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('home.cadastro.conhecimentos.excluir')); ?>" method="POST">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <input type="hidden" name="id" value="<?php echo e($userconhecimento->id); ?>">
                                                <button type="submit" onclick="return confirm('Deseja realmente executar esta ação?')" class="btn btn-danger"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
                                            </form>
                                        </td>
                                    </tr>

                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($userconhecimentos->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="myModalsave" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    <h4 class="modal-title">Escolha Seus Conhecimentos</h4>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('home.cadastro.conhecimento.store')); ?>" method="POST" id="save">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">                            
                        <select class="form-control" name="id">
                        <?php $__currentLoopData = $conhecimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conhecimento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($conhecimento->id); ?>"><?php echo e($conhecimento->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select> 
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
                    <button type="button" class="btn btn-primary" onclick="update('save');">Salvar</button>
                </div>
                    </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials-user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>