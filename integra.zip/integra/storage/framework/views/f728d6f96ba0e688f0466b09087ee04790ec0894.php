   <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script type="text/javascript">
    function update($id)

    {

        document.getElementById($id).submit();

    }
</script>
</html>