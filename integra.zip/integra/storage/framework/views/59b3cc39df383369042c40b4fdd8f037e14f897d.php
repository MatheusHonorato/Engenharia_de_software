<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-8 col-md-offset-2 col-xs-12">

                <div class="panel panel-default">

                <div class="panel-heading">Áreas

                </div>

                <div class="panel-body">

                    <table class="table table-hover">

                        <thead>

                            <button href="#myModalsave" class="btn btn-success pull-right" data-toggle="modal"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>Novo</button>

                            <tr>

                                <th>Nome</th>

                                <th></th>

                                <th></th>

                                <th>Editar</th>

                                <th>Remover</th>

                                <th></th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($area->name); ?></td>

                                <th scope="row">

                                <!-- Modal -->

                                    <div class="modal fade" id="myModal<?php echo e($area->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

                                        <div class="modal-dialog">

                                            <div class="modal-content">

                                                <div class="modal-header">

                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>

                                                    <h4 class="modal-title">Editar Área</h4>

                                                </div>

                                                <div class="modal-body">

                                                    <form action="<?php echo e(route('admin.home.cadastro.areas.update')); ?>" method="POST" id="<?php echo e($area->id); ?>">

                                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                                        <input type="hidden" name="id" value="<?php echo e($area->id); ?>">

                                                        <input type="text" class="form-control" name="name" value="<?php echo e($area->name); ?>" placeholder="Nome Área">

                                                </div>

                                                <div class="modal-footer">

                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>

                                                    <button type="button" class="btn btn-primary" onclick="update(<?php echo e($area->id); ?>);">Salvar</button>

                                                </div>

                                                    </form>

                                            </div><!-- /.modal-content -->

                                        </div><!-- /.modal-dialog -->

                                    </div><!-- /.modal -->

                                </th>

                                <td></td>

                                <td>

                                    <button href="#myModal<?php echo e($area->id); ?>" class="btn btn-primary" data-toggle="modal"><span class="glyphicon glyphicon-wrench" aria-hidden="true"></span></button>

                                </td>

                                <td>

                                    <form action="<?php echo e(route('admin.home.cadastro.areas.excluir')); ?>" method="POST">

                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                        <input type="hidden" name="id" value="<?php echo e($area->id); ?>">

                                        <button type="submit" onclick="return confirm('Deseja realmente executar esta ação?')" class="btn btn-danger"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>

                                        </form>

                                </td>

                                <td></td>

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>

                    <?php echo e($areas->links()); ?>


                </div>

            </div>

            </div>
    </div>

    <div class="modal fade" id="myModalsave" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">

                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>

                    <h4 class="modal-title">Nova Área</h4>

                </div>

                <div class="modal-body">

                    <form action="<?php echo e(route('admin.home.cadastro.areas.store')); ?>" method="POST" id="save">

                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">                            

                        <input  class="form-control" name="name" placeholder="Nome Área" type="text" required>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>

                    <button type="button" class="btn btn-primary" onclick="update('save');">Salvar</button>

                </div>

                    </form>

            </div><!-- /.modal-content -->

        </div><!-- /.modal-dialog -->

<?php $__env->stopSection(); ?>








<?php echo $__env->make('admin.layouts.partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>