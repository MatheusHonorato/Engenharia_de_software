

<?php $__env->startSection('content'); ?>
<style type="text/css">
    @media  only screen and (min-width: 700px) {
        #idiomas {
            margin-left: 82%;
        }
    }

    @media  only screen and (max-width: 600px) {
        #idiomas {
            margin-left: 80%;
        }
    }

    .required {
        color: red;
    }
</style>


    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Perfil</div>
                <div class="panel-body">
                     <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('emp.home.perfil.submit')); ?>" onsubmit="VerificaCPF();">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Telefone<span class="required">*</span></label>

                            <div class="col-md-6">
                                <input class="form-control" type="text" name="telefone" value="<?php echo e($perfilemp->telefone); ?>" placeholder="Telefone" onkeypress="mascara(this, '## #####-####')" maxlength="13" required>
                            </div>
                        </div>


                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">CNPJ<span class="required">*</span></label>

                            <div class="col-md-6">
                                <input class="form-control" type="text" name="cnpj" value="<?php echo e($perfilemp->cnpj); ?>" onkeypress="mascara(this, '###.###.###-##')" maxlength="14" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="state" class="col-md-4 control-label">Estado<span class="required">*</span></label>

                            <div class="col-md-6">
                              <select class="form-control" name="estado" required>
                                <option value="1">Minas Gerais</option>
                                <option value="2">São Paulo</option>
                                <option value="3">Rio de Janeiro</option>
                              </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label  class="col-md-4 control-label">Cidade<span class="required">*</span></label>

                            <div class="col-md-6">
                              <select class="form-control" name="cidade" required>
                                <option value="1">Montes Claros</option>
                              </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Bairro<span class="required">*</span></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" value="<?php echo e($perfilemp->bairro); ?>" placeholder="Bairro" name="bairro" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Logadouro<span class="required">*</span></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" value="<?php echo e($perfilemp->logadouro); ?>" placeholder="Logadouro" name="logadouro" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Número<span class="required">*</span></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" value="<?php echo e($perfilemp->numero); ?>" placeholder="Número" name="numero" pattern="[0-9]+$" oninvalid="setCustomValidity('Este campo aceita apenas números')" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="state" class="col-md-4 control-label">Complemento</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" value="<?php echo e($perfilemp->complemento); ?>" placeholder="Complemento" name="complemento">
                            </div>
                        </div>                       

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Facebook</label>

                            <div class="col-md-6">
                                <input class="form-control" type="text" value="<?php echo e($perfilemp->facebook); ?>" name="facebook" placeholder="Facebook">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Linkedin</label>

                            <div class="col-md-6">
                                <input class="form-control" type="text" value="<?php echo e($perfilemp->linkedin); ?>" name="linkedin" placeholder="Linkedin">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Instagram</label>

                            <div class="col-md-6">
                                <input class="form-control" type="text" value="<?php echo e($perfilemp->instagram); ?>" name="instagram" placeholder="Instagram">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Twitter</label>

                            <div class="col-md-6">
                                <input class="form-control" type="text" value="<?php echo e($perfilemp->twitter); ?>" name="twitter" placeholder="Twitter">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Atualizar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<script type="text/javascript">
    function mascara(t, mask){
        var i = t.value.length;
        var saida = mask.substring(1,0);
        var texto = mask.substring(i)
        if (texto.substring(0,1) != saida){
            t.value += texto.substring(0,1);
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emp.layouts.partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>