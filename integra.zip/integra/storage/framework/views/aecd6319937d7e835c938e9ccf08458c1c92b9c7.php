<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2 col-xs-12">
            <div class="row">
                <div class="panel panel-default">
                <div class="panel-heading">Oportunidades
                </div>
                <div class="panel-body">
                    <table class="table table-hover">
                        <thead>
                            <button href="#myModalsave" class="btn btn-success pull-right" data-toggle="modal"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>Nova</button>
                            <tr>
                                <th>Nome</th>
                                <th>Mais(matches)</th>
                                
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $oportunidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oportunidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($oportunidade->title); ?></td>
                                
                                <td>
                                    <form action="<?php echo e(route('emp.home.match.index')); ?>" method="POST">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="hidden" name="id" value="<?php echo e($oportunidade->id); ?>">
                                        <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></button>
                                    </form>
                                </td>
                                <td></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($oportunidades->links()); ?>

                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="myModalsave" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    <h4 class="modal-title">Nova Oportunidade</h4>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('emp.home.oportunidades.store')); ?>" method="POST" id="save">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">                            
                        <div class="form-group">
                            <input  class="form-control" name="title" placeholder="Titulo Oportunidade" type="text" required>
                        </div>

                        <div class="form-group">
                            <!--<select name="curso" class="form-control" required>-->
                            <div class="dropdown">
                                <button class="btn btn-default dropdown-toggle col-md-12 col-xs-12" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Cursos<span class="caret" id="cursos"></span>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                    <?php $__empty_1 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if($curso->status == 1): ?>
                                            <li><input type="checkbox" name="<?php echo e($curso->id); ?>" value="1"><?php echo e($curso->name); ?></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <?php endif; ?>
                                    <!--</select>-->
                                </ul>
                            </div>
                        </div>

                        <label></label>

                        <div class="form-group">
                            <!--<select name="curso" class="form-control" required>-->
                            <div class="dropdown">
                                <button class="btn btn-default dropdown-toggle col-md-12 col-xs-12" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Habilidades<span class="caret" id="habilidades"></span>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                    <?php $__empty_1 = true; $__currentLoopData = $habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habilidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if($habilidade->status == 1): ?>
                                            <li><input type="checkbox" name="<?php echo e($habilidade->id); ?>" value="1"><?php echo e($habilidade->name); ?></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <?php endif; ?>
                                    <!--</select>-->
                                </ul>
                            </div>
                        </div>

                        <label></label>

                        <div class="form-group">
                            <!--<select name="curso" class="form-control" required>-->
                            <div class="dropdown">
                                <button class="btn btn-default dropdown-toggle col-md-12 col-xs-12" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Atuação<span class="caret" id="atuacoes"></span>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenu3">
                                    <?php $__empty_1 = true; $__currentLoopData = $atuacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atuacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if($atuacao->status == 1): ?>
                                            <li><input type="checkbox" name="<?php echo e($atuacao->id); ?>" value="1"><?php echo e($atuacao->name); ?></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <?php endif; ?>
                                    <!--</select>-->
                                </ul>
                            </div>
                        </div>

                        <label></label>

                        <div class="form-group">
                            <!--<select name="curso" class="form-control" required>-->
                            <div class="dropdown">
                                <button class="btn btn-default dropdown-toggle col-md-12 col-xs-12" type="button" id="dropdownMenu4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Conhecimentos<span class="caret" id="conhecimentos"></span>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenu4">
                                    <?php $__empty_1 = true; $__currentLoopData = $conhecimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conhecimento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if($conhecimento->status == 1): ?>
                                            <li><input type="checkbox" name="<?php echo e($conhecimento->id); ?>" value="1"><?php echo e($conhecimento->name); ?></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <?php endif; ?>
                                    <!--</select>-->
                                </ul>
                            </div>
                        </div>

                        <label></label>

                        <div class="form-group">
                            <!--<select name="curso" class="form-control" required>-->
                            <div class="dropdown">
                                <button class="btn btn-default dropdown-toggle col-md-12 col-xs-12" type="button" id="dropdownMenu5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Periodo<span class="caret" id="periodos"></span>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenu5">
                                    <li><input type="checkbox" name="matutino" value="1">Matutino</li>
                                    <li><input type="checkbox" name="vespertino" value="1">Vespertino</li>
                                    <li><input type="checkbox" name="noturno" value="1">Noturno</li>
                                    <!--</select>-->
                                </ul>
                            </div>
                        </div>

                        <label></label>

                        <div class="form-group">
                          <label for="comment">Descrição:</label>
                          <textarea class="form-control" rows="5" name="desc" id="comment" placeholder="Escreva um pouco mais sobre a oportunidade"></textarea>
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
                    <button type="button" class="btn btn-primary" onclick="update('save');">Salvar</button>
                </div>
                    </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('emp.layouts.partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>