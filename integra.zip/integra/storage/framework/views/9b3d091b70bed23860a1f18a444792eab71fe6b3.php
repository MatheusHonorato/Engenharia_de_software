<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-8  col-md-offset-2 col-xs-12">

            <div class="panel panel-default">

                <div class="panel-heading">Cursos</div>

                <div class="panel-body">

                    <table class="table table-hover">

                        <thead>

                            <a href="<?php echo e(route('admin.home.cadastro.categorias.index')); ?>" class="pull-right"><button type="submit" class="btn btn-primary ">Categorias</button></a>

                                

                            <button href="#myModalsave" style="margin-right: 15px; !important" class="btn btn-success pull-right" data-toggle="modal"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>Novo</button>

                            <tr>

                              <th>Nome</th>

                              <th>Editar</th>

                              <th>Remover</th>

                            </tr>

                        </thead>

                        <tbody>

                            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <?php if($curso->status == 1): ?>

                                <td><?php echo e($curso->name); ?></td>

                                <th>

                                    <!-- Modal -->

                                    <div class="modal fade" id="myModal<?php echo e($curso->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

                                        <div class="modal-dialog">

                                            <div class="modal-content">

                                                <div class="modal-header">

                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>

                                                    <h4 class="modal-title">Editar Curso</h4>

                                                </div>

                                                <div class="modal-body">

                                                    <form action="<?php echo e(route('admin.home.cadastro.cursos.update')); ?>" method="POST" id="<?php echo e($curso->id); ?>">

                                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                                        <input type="hidden" name="id" value="<?php echo e($curso->id); ?>">

                                                        <div class="form-group">
                                                            <label>Nome do Curso</label>
                                                            <input type="text" class="form-control" name="name" value="<?php echo e($curso->name); ?>">

                                                        </div>

                                                        <div class="form-group">
                                                            <label>Área</label>
                                                            <select name="area" class="form-control">

                                                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                <?php if($area->id == $curso->id_area): ?>

                                                                    <option value="<?php echo e($area->id); ?>" selected><?php echo e($area->name); ?></option>

                                                                <?php endif; ?>

                                                                <?php if($area->id != $curso->id_area): ?>

                                                                    <option value="<?php echo e($area->id); ?>"><?php echo e($area->name); ?></option>

                                                                <?php endif; ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>

                                                        </div>

                                                        <div class="form-group">
                                                            <label>Categoria</label>
                                                            <select name="tipo" class="form-control">

                                                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                <?php if($tipo->id == $curso->id_tipo): ?>

                                                                    <option value="<?php echo e($tipo->id); ?>" selected><?php echo e($tipo->name); ?></option>

                                                                <?php endif; ?>

                                                                <?php if($tipo->id != $curso->id_tipo): ?>

                                                                    <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->name); ?></option>

                                                                <?php endif; ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>

                                                        </div>

                                                </div>

                                                <div class="modal-footer">

                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>

                                                    <button type="button" class="btn btn-primary" onclick="update(<?php echo e($curso->id); ?>);">Salvar</button>

                                                </div>

                                                    </form>

                                            </div><!-- /.modal-content -->

                                        </div><!-- /.modal-dialog -->

                                    </div><!-- /.modal -->

                                    <button href="#myModal<?php echo e($curso->id); ?>" class="btn btn-primary" data-toggle="modal"><span class="glyphicon glyphicon-wrench" aria-hidden="true"></span></button>

                                </th>



                                <td>

                                    <form action="<?php echo e(route('admin.home.cadastro.cursos.excluir')); ?>" method="POST">

                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                        <input type="hidden" name="id" value="<?php echo e($curso->id); ?>">

                                        <button type="submit" onclick="return confirm('Deseja realmente executar esta ação?')" class="btn btn-danger"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>

                                    </form>

                                </td>

                                <?php endif; ?>

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>

                    <?php echo e($cursos->links()); ?>


                </div>

            </div>

        </div>

    </div>

    <div class="modal fade" id="myModalsave" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">

                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>

                    <h4 class="modal-title">Novo Curso</h4>

                </div>

                <div class="modal-body">

                    <form action="<?php echo e(route('admin.home.cadastro.cursos.store')); ?>" method="POST" id="save">

                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">                            

                        <div class="form-group">

                            <label>Nome do Curso</label>

                            <input type="text" name="name" id="name" class="form-control" placeholder="Nome do Curso" required>

                        </div>

                        <div class="form-group">

                            <label>Área</label>

                            <select name="area" class="form-control" required>

                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($area->id); ?>"><?php echo e($area->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>

                        <div class="form-group">

                            <label>Categoria</label>

                            <select name="tipo" class="form-control" required>

                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>

                    <button type="button" class="btn btn-primary" onclick="update('save');">Salvar</button>

                </div>

                    </form>

            </div><!-- /.modal-content -->

        </div><!-- /.modal-dialog -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>