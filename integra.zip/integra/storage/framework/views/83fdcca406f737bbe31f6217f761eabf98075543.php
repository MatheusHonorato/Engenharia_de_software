Olá <?php echo e($name); ?>, seu cadastro em nossa plataforma <?php echo e($var); ?>.
<br/>
At. Equipe Integra.
