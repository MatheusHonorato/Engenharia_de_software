

<?php $__env->startSection('content'); ?>
<style type="text/css">
    @media  only screen and (min-width: 700px) {
        #idiomas {
            margin-left: 82%;
        }
    }

    @media  only screen and (max-width: 600px) {
        #idiomas {
            margin-left: 80%;
        }
    }

    .required {
        color: red;
    }
</style>


    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Habilidades</div>
                <div class="panel-body">
                    <table class="table table-hover">
                        <thead>
                            <button href="#myModalsave" class="btn btn-success pull-right" data-toggle="modal"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>Novo</button></span></button></a>
                            <tr>
                              <th>Nome</th>
                              <th>Remover</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $userhabilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userhabilidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habilidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($userhabilidade->id_habilidade == $habilidade->id): ?>

                                    <tr>
                                        <td><?php echo e($habilidade->name); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('home.cadastro.user.habilidades.excluir')); ?>" method="POST">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <input type="hidden" name="id" value="<?php echo e($userhabilidade->id); ?>">
                                                <button type="submit" onclick="return confirm('Deseja realmente executar esta ação?')" class="btn btn-danger"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
                                            </form>
                                        </td>
                                    </tr>

                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($userhabilidades->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="myModalsave" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    <h4 class="modal-title">Escolha Suas Habilidades</h4>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('home.cadastro.user.habilidades.store')); ?>" method="POST" id="save">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">                            
                        <select class="form-control" name="id">
                        <?php $__currentLoopData = $habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habilidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($habilidade->id); ?>"><?php echo e($habilidade->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select> 
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
                    <button type="button" class="btn btn-primary" onclick="update('save');">Salvar</button>
                </div>
                    </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials-user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>