   <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>