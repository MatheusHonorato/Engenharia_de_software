<!DOCTYPE html>
<html>
<head>
  <title>Integra 2.0</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <link rel="shortcut icon" href="icones-aplicacao/icon.ico">
  <link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">
</head>