<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Cursos</div>
                <div class="panel-body">
                    <table class="table">
                        <thead>
                            <tr>
                              <th>Nome</th>
                              <th>Área</th>
                              <th>Categoria</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <form action="<?php echo e(route('admin.home.cadastro.cursos.store')); ?>" method="POST">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <td>
                                            <input type="text" name="name" id="name" class="form-control" placeholder="Nome" required="" autofocus="">
                                        </td>

                                        <td>
                                            <select name="area" class="form-control">
                                                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($area->id); ?>"><?php echo e($area->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>

                                        <td>
                                            <select name="tipo" class="form-control">
                                                <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>

                                        <td>
                                            <button type="submit" class="btn btn-success pull-right"><span aria-hidden="true">Adicionar</span></button>
                                        </td>

                                    </form>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.layouts.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.layouts.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>