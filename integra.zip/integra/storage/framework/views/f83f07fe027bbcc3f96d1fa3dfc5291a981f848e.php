<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-8 col-md-offset-2 col-xs-12">

                <div class="panel panel-default">

                <div class="panel-heading">Matchs

                </div>

                <div class="panel-body">

                    <table class="table table-hover">

                        <thead>

                            <tr>

                                <th>Aluno</th>

                                <th>Email</th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>

                                <?php $__empty_2 = true; $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>

                                    <?php if($aluno->id == $match->id_aluno): ?>

                                        <td><?php echo e($aluno->name); ?></td>

                                        <td><?php echo e($aluno->email); ?></td>

                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>



                                <?php endif; ?>

                                <td></td>

                                <td>

                                    

                                </td>

                                

                                <td></td>

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>



                            <?php endif; ?>

                        </tbody>

                    </table>

                    <?php echo e($matches->links()); ?>


                </div>

            </div>

            </div>

    </div>



<?php $__env->stopSection(); ?>








<?php echo $__env->make('admin.layouts.partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>