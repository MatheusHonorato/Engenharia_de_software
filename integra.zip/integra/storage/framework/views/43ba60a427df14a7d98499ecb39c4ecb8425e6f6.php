<?php echo $__env->make('emp.layouts.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('emp.layouts.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php echo $__env->make('emp.layouts.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
