<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">

        <div class="col-md-12">



            <div class="panel panel-default col-md-2">

              <div class="panel-body">

                <?php echo e($userAmount); ?><br>

                alunos

              </div>

            </div>



            <div class="panel panel-default col-md-2 col-md-offset-1">

              <div class="panel-body">

                <?php echo e($empAmount); ?><br>

                empresas

              </div>

            </div>



            <div class="panel panel-default col-md-2 col-md-offset-1">

              <div class="panel-body">

                <?php echo e($matchAmount); ?><br>

                matchs

              </div>

            </div>



            <a href="#">

                <div class="panel panel-default col-md-3 col-md-offset-1">

                  <div class="panel-body">

                    Rankings

                    <br>

                  </div>

                </div>

            </a>



            <!--panel-->

            <div class="panel panel-default col-md-5">

                <div class="panel-heading">Habilidades alunos universidade</div>

                <div class="panel-body">

                    <!--<h4>Ranking Alunos Habilidades, Ranking avaliação empresas, Estatísticas Matchs(quantidade de matchs por mes)</h4>-->

                    <!--card atd alunos, empresas matchs-->

                    <div>

                        <canvas id="skills"></canvas>

                    </div>

                </div>

                   <script>

                var ctx = document.getElementById("skills").getContext('2d');

                var myChart = new Chart(ctx, {

                    type: 'bar',

                    data: {



                        labels: [



                        <?php $__currentLoopData = $habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habilidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                        "<?php echo e($habilidade->name); ?>",



                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        ],

                        datasets: [{

                            label: '',

                            data: [



                            <?php $__currentLoopData = $habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habilidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                            "<?php echo e($habilidade->amount); ?>",



                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            ],

                            backgroundColor: [



                            <?php for($i = 0; $i < $countHabilidades; $i++): ?>

                                'rgba(54, 162, 235, 0.2)',

                            <?php endfor; ?>

                            ],

                            borderColor: [



                            <?php for($i = 0; $i < $countHabilidades; $i++): ?>

                                'rgba(54, 162, 235, 1)',

                            <?php endfor; ?>



                            ],

                            borderWidth: 1

                        }]

                    },

                    options: {

                      legend: {

                          display: false

                      },

                        scales: {

                            yAxes: [{

                                ticks: {

                                    beginAtZero:true

                                }

                            }]

                        }

                    }

                });

              </script>

                </div>

            <!-- panel -->



            <!-- panel -->

            <div class="panel panel-default col-md-5 col-md-offset-2">

                <div class="panel-heading">Áreas alunos universidade</div>

                <div class="panel-body">

                    <!--<h4>Ranking Alunos Habilidades, Ranking avaliação empresas, Estatísticas Matchs(quantidade de matchs por mes)</h4>-->

                    <div>

                        <canvas id="areas"></canvas>

                    </div>

                </div>

               <script>

                var ctx = document.getElementById("areas").getContext('2d');

                var myChart = new Chart(ctx, {

                    type: 'bar',

                    data: {



                        labels: [



                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                        "<?php echo e($area->name); ?>",



                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        ],

                        datasets: [{

                            label: '',

                            data: [



                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                            "<?php echo e($area->amount); ?>",



                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            ],

                            backgroundColor: [



                            <?php for($i = 0; $i < $countAreas; $i++): ?>

                                'rgba(54, 162, 235, 0.2)',

                            <?php endfor; ?>

                            ],

                            borderColor: [



                            <?php for($i = 0; $i < $countAreas; $i++): ?>

                                'rgba(54, 162, 235, 1)',

                            <?php endfor; ?>



                            ],

                            borderWidth: 1

                        }]

                    },

                    options: {

                      legend: {

                          display: false

                      },

                        scales: {

                            yAxes: [{

                                ticks: {

                                    beginAtZero:true

                                }

                            }]

                        }

                    }

                });

              </script>

                </div>

            </div>

            <!--panel-->

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>




<?php echo $__env->make('admin.layouts.partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>