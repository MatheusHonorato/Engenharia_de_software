<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OportunidadeCursos extends Model
{
    //
}
