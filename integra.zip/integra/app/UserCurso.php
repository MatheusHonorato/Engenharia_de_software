<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserCurso extends Model
{
    //
}
